﻿namespace WEBAPI.DTOs
{
    public class RolDto
    {
        public int Id { get; set; }
        public string Descripcion { get; set; } = null!;
    }
}
